-- -------- aula4extra1 --------
--
--       SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 04/09/2023
-- Autor(es) ..............: Pedro Vitor Augusto de Jesus
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4extra1
--
-- PROJETO => 01 Base de Dados
-- 
-- Ultimas Alteracoes
--   04/09/2023 => Criação do script

use aula4extra1;

DROP TABLE cidade;
DROP TABLE estado;